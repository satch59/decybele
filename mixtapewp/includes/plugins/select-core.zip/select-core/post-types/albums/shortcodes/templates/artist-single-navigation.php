<div class="qodef-controls">
    <div class="qodef-controls-navigate">
        <span class="qodef-control-button qodef-control-button-next lnr lnr-chevron-right">

        </span>
        <span class="qodef-control-button qodef-control-button-prev lnr lnr-chevron-left">

        </span>
    </div>
</div><!--  /controls -->
<span class="qodef-control-button qodef-control-button-back lnr lnr-arrow-left"></span>
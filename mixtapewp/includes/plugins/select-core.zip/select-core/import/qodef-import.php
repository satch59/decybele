<?php
if (!function_exists ('add_action')) {
    header(esc_html__('Status: 403 Forbidden', 'qodef-cpt'));
    header('HTTP/1.1 403 Forbidden');
    exit();
}
class MixtapeQodeImport {

    public $message = "";
    public $attachments = false;

	private $revSliderFolder;
	private $importURI;

    function __construct() {

		$this->revSliderFolder 	= 'qodef-rev-sliders';
		$this->importURI		= 'http://export.select-themes.com/';

        add_action('admin_menu', array(&$this, 'qodef_admin_import'));
        add_action('admin_init', array(&$this, 'qodef_register_theme_settings'));

    }
    function qodef_register_theme_settings() {
        register_setting( 'qodef_options_import_page', 'qodef_options_import');
    }

    function init_qodef_import() {
        if(isset($_REQUEST['import_option'])) {
            $import_option = $_REQUEST['import_option'];
            if($import_option == 'content'){
                $this->import_content('proya_content.xml');
            }elseif($import_option == 'custom_sidebars') {
                $this->import_custom_sidebars('custom_sidebars.txt');
            } elseif($import_option == 'widgets') {
                $this->import_widgets('widgets.txt','custom_sidebars.txt');
            } elseif($import_option == 'options'){
                $this->import_options('options.txt');
            }elseif($import_option == 'menus'){
                $this->import_menus('menus.txt');
            }elseif($import_option == 'settingpages'){
                $this->import_settings_pages('settingpages.txt');
            }elseif($import_option == 'complete_content'){
                $this->import_content('proya_content.xml');
                $this->import_options('options.txt');
                $this->import_widgets('widgets.txt','custom_sidebars.txt');
                $this->import_menus('menus.txt');
                $this->import_settings_pages('settingpages.txt');
                $this->message = esc_html__("Content imported successfully", 'qodef-cpt');
            }
        }
    }

    public function import_content($file){
		ob_start();
		require_once(QODE_CORE_ABS_PATH . '/import/class.wordpress-importer.php');
		$qodef_import = new WP_Import();
		set_time_limit(0);

		$qodef_import->fetch_attachments = $this->attachments;
		$returned_value = $qodef_import->import($file);
		if(is_wp_error($returned_value)){
			$this->message = esc_html__("An Error Occurred During Import", 'qodef-cpt');
		}
		else {
			$this->message = esc_html__("Content imported successfully", 'qodef-cpt');
		}
		ob_get_clean();
    }

    public function import_widgets($file, $file2){
        $this->import_custom_sidebars($file2);
        $options = $this->file_options($file);
        foreach ((array) $options['widgets'] as $qodef_widget_id => $qodef_widget_data) {
            update_option( 'widget_' . $qodef_widget_id, $qodef_widget_data );
        }
        $this->import_sidebars_widgets($file);
        $this->message = esc_html__("Widgets imported successfully", 'qodef-cpt');
    }

    public function import_sidebars_widgets($file){
        $qodef_sidebars = get_option("sidebars_widgets");
        unset($qodef_sidebars['array_version']);
        $data = $this->file_options($file);
        if ( is_array($data['sidebars']) ) {
            $qodef_sidebars = array_merge( (array) $qodef_sidebars, (array) $data['sidebars'] );
            unset($qodef_sidebars['wp_inactive_widgets']);
            $qodef_sidebars = array_merge(array('wp_inactive_widgets' => array()), $qodef_sidebars);
            $qodef_sidebars['array_version'] = 2;
            wp_set_sidebars_widgets($qodef_sidebars);
        }
    }

    public function import_custom_sidebars($file){
        $options = $this->file_options($file);
        update_option( 'qodef_sidebars', $options);
        $this->message = esc_html__("Custom sidebars imported successfully", 'qodef-cpt');
    }

    public function import_options($file){
        $options = $this->file_options($file);
        update_option( 'qodef_options_mixtape', $options);
        $this->message = esc_html__("Options imported successfully", 'qodef-cpt');
    }

    public function import_menus($file){
        global $wpdb;
        $qodef_terms_table = $wpdb->prefix . "terms";
        $this->menus_data = $this->file_options($file);
        $menu_array = array();
        foreach ($this->menus_data as $registered_menu => $menu_slug) {
            $term_rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $qodef_terms_table where slug=%s", $menu_slug), ARRAY_A);
            if(isset($term_rows[0]['term_id'])) {
                $term_id_by_slug = $term_rows[0]['term_id'];
            } else {
                $term_id_by_slug = null;
            }
            $menu_array[$registered_menu] = $term_id_by_slug;
        }
        set_theme_mod('nav_menu_locations', array_map('absint', $menu_array ) );

    }
    public function import_settings_pages($file){
        $pages = $this->file_options($file);
        foreach($pages as $qodef_page_option => $qodef_page_id){
            update_option( $qodef_page_option, $qodef_page_id);
        }
    }

    public function file_options($file){
        $file_content = "";
        $file_for_import = get_template_directory() . '/includes/import/files/' . $file;
        /*if ( file_exists($file_for_import) ) {
            $file_content = $this->qodef_file_contents($file_for_import);
        } else {
            $this->message = esc_html__("File doesn't exist", 'qodef-cpt');
        }*/
        $file_content = $this->qodef_file_contents($file);
        if ($file_content) {
            $unserialized_content = unserialize(base64_decode($file_content));
            if ($unserialized_content) {
                return $unserialized_content;
            }
        }
        return false;
    }

    function qodef_file_contents( $path ) {
		$url      = "http://export.select-themes.com/".$path;
		$response = wp_remote_get($url);
		$body     = wp_remote_retrieve_body($response);
		return $body;
    }

    function qodef_admin_import() {
        if (qodef_core_theme_installed()) {
            global $mixtape_qodef_Framework;

            $slug = "_tabimport";
            $this->pagehook = add_submenu_page(
                'mixtape_qodef_theme_menu',
                esc_html__('Select Options - Select Import', 'qodef-cpt'),                   // The value used to populate the browser's title bar when the menu page is active
                esc_html__('Import', 'qodef-cpt'),                   // The text of the menu in the administrator's sidebar
                'administrator',                  // What roles are able to access the menu
                'mixtape_qodef_theme_menu'.$slug,                // The ID used to bind submenu items to this menu
                array($mixtape_qodef_Framework->getSkin(), 'renderImport')
            );

            add_action('admin_print_scripts-'.$this->pagehook, 'mixtape_qodef_enqueue_admin_scripts');
            add_action('admin_print_styles-'.$this->pagehook, 'mixtape_qodef_enqueue_admin_styles');
            //$this->pagehook = add_menu_page('Select Import', 'Select Import', 'manage_options', 'qodef_options_import_page', array(&$this, 'qodef_generate_import_page'),'dashicons-download');
        }
    }

	public function rev_sliders() {
		$rev_sldiers = array(
			'Album-Into.zip',
			'Album-Showcase.zip',
			'Band-Home.zip',
			'Blog-Home.zip',
			'landing.zip',
			'Landing-Album-Pages.zip',
			'Landing-Bottom.zip',
			'Landing-Player.zip',
			'Main-Home.zip',
			'music-festival-home.zip',
			'Shop-Home.zip',
			'Video-Home.zip'
		);

		return $rev_sldiers;
	}

	public function create_rev_slider_files($folder) {
		$rev_list = $this->rev_sliders();
		$dir_name = $this->revSliderFolder;

		$upload		= wp_upload_dir();
		$upload_dir = $upload['basedir'];
		$upload_dir = $upload_dir . '/' . $dir_name;
		if (!is_dir($upload_dir)) {
			mkdir($upload_dir, 0700);
			mkdir($upload_dir . '/' . $folder, 0700);
		}

		foreach ($rev_list as $rev_slider) {
			file_put_contents(WP_CONTENT_DIR . '/uploads/' . $dir_name . '/'. $folder . '/' . $rev_slider, file_get_contents($this->importURI .'/' . $folder . '/revslider/' . $rev_slider));
		}
	}

	public function rev_slider_import($folder){
		$this->create_rev_slider_files($folder);

		$rev_sliders = $this->rev_sliders();
		$dir_name = $this->revSliderFolder;
		$absolute_path = __FILE__;
		$path_to_file = explode( 'wp-content', $absolute_path );
		$path_to_wp = $path_to_file[0];

		require_once( $path_to_wp.'/wp-load.php' );
		require_once( $path_to_wp.'/wp-includes/functions.php');
		require_once( $path_to_wp.'/wp-admin/includes/file.php');

		$rev_slider_instance = new RevSlider();

		foreach ($rev_sliders as $rev_slider) {
			$nf = WP_CONTENT_DIR . '/uploads/' . $dir_name . '/' . $folder . '/' . $rev_slider;
			$rev_slider_instance->importSliderFromPost(true, true, $nf);
		}
	}

}

function qodef_init_import_object(){
    global $mixtape_qodef_import_object;
    $mixtape_qodef_import_object = new MixtapeQodeImport();
}

add_action('init', 'qodef_init_import_object');

if(!function_exists('mixtape_qodef_dataImport')){
    function mixtape_qodef_dataImport(){
        global $mixtape_qodef_import_object;

        if ($_POST['import_attachments'] == 1)
            $mixtape_qodef_import_object->attachments = true;
        else
            $mixtape_qodef_import_object->attachments = false;

        $folder = "mixtape/";
        if (!empty($_POST['example']))
            $folder = $_POST['example']."/";

        $mixtape_qodef_import_object->import_content($folder.$_POST['xml']);

		mixtape_qodef_update_meta_fields_after_import();

        die();
    }

    add_action('wp_ajax_qodef_dataImport', 'mixtape_qodef_dataImport');
}

if(!function_exists('mixtape_qodef_widgetsImport')){
    function mixtape_qodef_widgetsImport(){
        global $mixtape_qodef_import_object;

        $folder = "mixtape/";
        if (!empty($_POST['example']))
            $folder = $_POST['example']."/";

        $mixtape_qodef_import_object->import_widgets($folder.'widgets.txt',$folder.'custom_sidebars.txt');

        die();
    }

    add_action('wp_ajax_qodef_widgetsImport', 'mixtape_qodef_widgetsImport');
}

if(!function_exists('mixtape_qodef_optionsImport')){
    function mixtape_qodef_optionsImport(){
        global $mixtape_qodef_import_object;

        $folder = "mixtape/";
        if (!empty($_POST['example']))
            $folder = $_POST['example']."/";

        $mixtape_qodef_import_object->import_options($folder.'options.txt');

        die();
    }

    add_action('wp_ajax_qodef_optionsImport', 'mixtape_qodef_optionsImport');
}

if(!function_exists('mixtape_qodef_otherImport')){
    function mixtape_qodef_otherImport(){
        global $mixtape_qodef_import_object;

        $folder = "mixtape/";
        if (!empty($_POST['example']))
            $folder = $_POST['example']."/";

        $mixtape_qodef_import_object->import_options($folder.'options.txt');
        $mixtape_qodef_import_object->import_widgets($folder.'widgets.txt',$folder.'custom_sidebars.txt');
        $mixtape_qodef_import_object->import_menus($folder.'menus.txt');
        $mixtape_qodef_import_object->import_settings_pages($folder.'settingpages.txt');
		if(qodef_cpt_is_revolution_slider_installed()){
			$mixtape_qodef_import_object->rev_slider_import($folder);
		}

        die();
    }

    add_action('wp_ajax_qodef_otherImport', 'mixtape_qodef_otherImport');
}
if(!function_exists('mixtape_qodef_update_meta_fields_after_import')){
	function mixtape_qodef_update_meta_fields_after_import(){
		global $wpdb;
		$url = home_url( '/' );

		$meta_values = $wpdb->get_results("SELECT * FROM $wpdb->postmeta WHERE meta_key = 'qodef_track_file'");

		foreach ( $meta_values as $meta_value ) {
			$new_value = mixtape_qodef_recalcserializedlengths(str_replace('http://mixtape.select-themes.com/', $url, $meta_value->meta_value));

			$wpdb->update(
				$wpdb->postmeta,
				array(
					'meta_value' => $new_value,
				),
				array( 'meta_id' => $meta_value->meta_id )
			);
		}
	}
}
if(!function_exists('mixtape_qodef_recalcserializedlengths')){
	function mixtape_qodef_recalcserializedlengths($sObject) {

		$ret = preg_replace('!s:(\d+):"(.*?)";!e', "'s:'.strlen('$2').':\"$2\";'", $sObject );

		return $ret;
	}
}

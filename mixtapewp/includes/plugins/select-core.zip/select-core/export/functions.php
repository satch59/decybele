<?php

if(!function_exists('mixtape_qodef_export_options')) {
	/**
	 * Function that saves theme options to db.
	 * It hooks to ajax wp_ajax_qodef_save_options action.
	 */
	function mixtape_qodef_export_options() {
		$options = get_option("qodef_options_mixtape");
		$output = base64_encode(serialize($options));

		return $output;
	}

}

if(!function_exists('mixtape_qodef_import_theme_options')) {
	/**
	 * Function that import theme options to db.
	 * It hooks to ajax wp_ajax_mixtape_qodef_import_theme_options action.
	 */
	function mixtape_qodef_import_theme_options() {

		if(current_user_can('administrator')) {
			if (empty($_POST) || !isset($_POST)) {
				mixtape_qodef_ajax_status('error', esc_html__('Import field is empty', 'qodef-cpt'));
			} else {
				$data = $_POST;
				if (wp_verify_nonce($data['nonce'], 'qodef_import_theme_options_secret_value')) {
					$content = $data['content'];
					$unserialized_content = unserialize(base64_decode($content));
					update_option( 'qodef_options_mixtape', $unserialized_content);
					mixtape_qodef_ajax_status('success', esc_html__('Options are imported successfully', 'qodef-cpt'));
				} else {
					mixtape_qodef_ajax_status('error', esc_html__('Non valid authorization', 'qodef-cpt'));
				}

			}
		} else {
			mixtape_qodef_ajax_status('error', esc_html__('You don\'t have privileges for this operation', 'qodef-cpt'));
		}
	}

	add_action('wp_ajax_mixtape_qodef_import_theme_options', 'mixtape_qodef_import_theme_options');
}

if( ! function_exists( 'mixtape_qodef_ajax_status' ) ) {

	/**
	 * Function that return status from ajax functions
	 *
	 */

	function mixtape_qodef_ajax_status($status, $message, $data = NULL) {

		$response = array (
			'status' => $status,
			'message' => $message,
			'data' => $data
		);

		$output = json_encode($response);

		exit($output);

	}

}